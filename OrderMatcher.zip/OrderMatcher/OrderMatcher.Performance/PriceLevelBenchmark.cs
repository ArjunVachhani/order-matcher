﻿using BenchmarkDotNet.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace OrderMatcher.Performance
{
    [MinColumn, MaxColumn, MeanColumn, MedianColumn]
    public class PriceLevelBenchmark
    {
    }
}
