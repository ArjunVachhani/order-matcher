﻿namespace OrderMatcher
{
    public class OrderTrigger
    {
        public ulong OrderId { get; set; }
        public long Timestamp { get; set; }
    }
}
