﻿namespace OrderMatcher
{
    public class CancelRequest
    {
        public ulong OrderId { get; set; }
    }
}
