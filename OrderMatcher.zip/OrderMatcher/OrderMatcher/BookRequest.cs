﻿namespace OrderMatcher
{
    public class BookRequest
    {
        public int LevelCount { get; set; }
    }
}
